<?php
$host="localhost";
$user="id12568955_user";
$pass = "12345";
$db = "id12568955_sisfo";

$con = mysqli_connect($host,$user,$pass,$db);

'if($con){
    echo"";
    if($con_db){
    echo"";
    }
    else{
    echo "Tidak terkoneksi dengan $db";
    }
    }
    
else{
  echo " Nggak Konek Cuy..";
  }'

?>