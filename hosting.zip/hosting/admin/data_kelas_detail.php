<?php
include"../koneksi.php";
$sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$_GET[id_kelas]");
$rk = mysqli_fetch_array($sqlk);
?>

<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">DATA DETAIL KELAS</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Kode Kelas :</Label>
                          <input type="text" class="form-control" name="kd_kelas" value="<?php echo"$rk[kd_kelas]"?>">
                    </div>


                    <div class="form-group">
                          <Label>Nama Kelas :</Label>
                          <input type="text" class="form-control" name="nm_kelas" value="<?php echo"$rk[nm_kelas]"?>">
                    </div>

                     <div class="form-group">
                          <Label>Kapasitas :</Label>
                          <input type="text" class="form-control" name="kapasitas" value="<?php echo"$rk[kapasitas]"?>">
                      </div>



                      

          
                      <center><a href="index_admin.php?page=data_kelas"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Kembali </a></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>
