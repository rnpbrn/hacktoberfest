<?php
  
include "../koneksi.php";
$lokasi_file = $_FILES['foto']['tmp_name'];
$tipe_file  = $_FILES['foto']['type'];
$nama_file  = $_FILES['foto']['name'];
$direktori  = "../mahasiswa/image/$nama_file";

if (!empty($lokasi_file)){
 move_uploaded_file($lokasi_file, $direktori);
 mysqli_query($con,"insert into t_mahasiswa (nim_mahasiswa,nm_mahasiswa,gender,alamat,email,nohp,foto) values('$_POST[nim_mahasiswa]','$_POST[nm_mahasiswa]','$_POST[gender]','$_POST[alamat]','$_POST[email]','$_POST[nohp]','$nama_file')");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_mahasiswa';
        </script>";
}  
?>