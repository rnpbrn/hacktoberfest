<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">DATA MATA KULIAH</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Kode Mata Kuliah :</Label>
                          <input type="text" class="form-control" name="kd_mk" placeholder="Enter The Code..">
                    </div>


                    <div class="form-group">
                          <Label>Nama Mata Kuliah :</Label>
                          <input type="text" class="form-control" name="nm_mk" placeholder="Enter The  Name..">
                    </div>

                     <div class="form-group">
                          <Label>SKS :</Label>
                          <input type="text" class="form-control" name="sks" placeholder="Enter The Number SKS..">
                      </div>



                      

          
          <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>


<?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        include"../koneksi.php";
mysqli_query($con,"insert into t_matakuliah (
    kd_mk,nm_mk,sks) values ('$_POST[kd_mk]','$_POST[nm_mk]',
    '$_POST[sks]')");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_matakuliah';
    </script>";
    }

?>