<?php
    include "../koneksi.php";
  mysqli_query($con,"delete from t_mahasiswa where id_mahasiswa='$_GET[id_mahasiswa]'");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_mahasiswa';
        </script>";
  ?>