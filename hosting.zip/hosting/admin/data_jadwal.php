<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Jadwal</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="index_admin.php?page=data_jadwal_input"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Tambah Data Jadwal</a><p></p>

                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Nama Kelas</th>
                      <th>Nama Dosen </th>
                      <th>Matakuliah </th>
                      <th>Ruangan</th>
                      <th>Waktu</th>
                      <th>Action</th>
                    </tr>

                    <tfoot>
                      <th>No.</th>
                      <th>Nama Kelas</th>
                      <th>Nama Dosen </th>
                      <th>Matakuliah </th>
                      <th>Ruangan</th>
                      <th>Waktu</th>
                      <th align='center'>Action</th>
                    </tfoot>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqlj = mysqli_query($con," select * from t_jadwal ");
                  $no=1;
                  while($rj= mysqli_fetch_array($sqlj)){
                    $sqlk = mysqli_query($con,"select * from t_kelas where t_kelas.id_kelas=$rj[id_kelas]");
                    $rk= mysqli_fetch_array($sqlk);
                    $sqld = mysqli_query($con,"select * from t_dosen where t_dosen.id_dosen=$rj[id_dosen]");
                    $rd= mysqli_fetch_array($sqld);
                    $sqlmk = mysqli_query($con,"select * from t_matakuliah where t_matakuliah.id_mk=$rj[id_mk]");
                    $rmk= mysqli_fetch_array($sqlmk);
                    $sqlr = mysqli_query($con,"select * from t_ruangan where t_ruangan.id_ruangan=$rj[id_ruangan]");
                    $rr= mysqli_fetch_array($sqlr);
                        echo"
                        <tr>
                        <td>$no</td>
                        <td>$rk[nm_kelas]</td>
                        <td>$rd[nm_dosen]</td>
                        <td>$rmk[nm_mk]</td>
                        <td>$rr[nm_ruangan]</td>
                        <td>$rj[hari] / $rj[jam]</td>
                        <td align='center'>
                        <a href='index_admin.php?page=data_jadwal_delete&id_jadwal=$rj[id_jadwal]'  class='d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm'>
                        Delete Jadwal </a></td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>