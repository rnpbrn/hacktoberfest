<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Ruangan</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="index_admin.php?page=data_ruangan_input"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Tambah Data Ruangan</a><p></p>

                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Kode Ruangan</th>
                      <th>Nama Ruangan </th>
                      <th>Kapasitas </th>
                      <th>Action</th>
                    </tr>

                    <tfoot>
                      <th>No.</th>
                      <th>Kode Ruangan</th>
                      <th>Nama Ruangan </th>
                      <th>Kapasitas </th>
                      <th>Action</th>
                    </tfoot>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqlr = mysqli_query($con," select * from t_ruangan ");
                  $no=1;
                  while($rr= mysqli_fetch_array($sqlr)){
                        echo"
                        <tr>
                        <td>$no</td>
                        <td>$rr[kd_ruangan]</td>
                        <td>$rr[nm_ruangan]</td>
                        <td>$rr[kapasitas]</td>
                        <td align='center'>
                        <a href='index_admin.php?page=data_ruangan_edit&id_ruangan=$rr[id_ruangan]'  class='d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm'>
                        Edit </a>
                        <a href='index_admin.php?page=data_ruangan_delete&id_ruangan=$rr[id_ruangan]'  class='d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm'>
                        Delete </a></td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>