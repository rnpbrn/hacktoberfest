          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Mahasiswa</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="index_admin.php?page=data_mahasiswa_input"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Tambah Data Mahasiswa </a><p></p>

                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Foto</th>
                      <th>NIM</th>
                      <th>Nama </th>
                      <th>Gender </th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>


                  <?php

                  include"../koneksi.php";
                  $sqlm = mysqli_query($con," select * from t_mahasiswa ");
                  $no=1;
                  while($rm= mysqli_fetch_array($sqlm)){
                        echo"
                        <tr>
                        <td>$no</td>
                        <td align='center' > <img src='../mahasiswa/image/$rm[foto]' width='60px' height='60px' alt='foto' > </td>
                        <td>$rm[nim_mahasiswa]</td>
                        <td>$rm[nm_mahasiswa]</td>
                        <td>$rm[gender]</td>
                        <td align='center'>
                        <a href='index_admin.php?page=data_mahasiswa_detail&id_mahasiswa=$rm[id_mahasiswa]'  class='d-none d-sm-inline-block btn btn-sm btn-success shadow-sm'>
                        Detail </a>
                        <a href='index_admin.php?page=data_mahasiswa_edit&id_mahasiswa=$rm[id_mahasiswa]'  class='d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm'>
                        Info </a>
                        <a href='index_admin.php?page=data_mahasiswa_delete&id_mahasiswa=$rm[id_mahasiswa]'  class='d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm'>
                        Delete </a>";

                        $sqlu = mysqli_query($con," select * from t_user where username = '$rm[nim_mahasiswa]'");
                        $ru= mysqli_fetch_array($sqlu);

                        if($ru['username']==$rm['nim_mahasiswa']){
                          echo"";
                        
                        }
                        
                        else{
                        
                          echo"
                          <a href='index_admin.php?page=data_mahasiswa_add&id_mahasiswa=$rm[id_mahasiswa]'  class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
                          Add User </a>";
                        }
                        
                        echo"</td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>