<?php
    include "../koneksi.php";
  mysqli_query($con,"delete from t_jadwal where id_jadwal='$_GET[id_jadwal]'");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_jadwal';
        </script>";
  ?>