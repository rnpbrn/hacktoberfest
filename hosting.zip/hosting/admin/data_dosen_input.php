<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">FORM INPUT DATA  DOSEN</h6>
                </div>
                <div class="card-body">
				    <form method="POST" enctype="multipart/form-data" action="index_admin.php?page=data_dosen_input_aksi">
          
                    <div class="form-group">
                          <Label>NIDN Dosen :</Label>
                          <input type="text" class="form-control" name="nidn" placeholder="Enter Your NIDN..">
                    </div>


                    <div class="form-group">
                          <Label>Nama Dosen :</Label>
                          <input type="text" class="form-control" name="nm_dosen" placeholder="Enter Your Name..">
                    </div>

                    <div class="form-group">
                          <Label>Gender :</Label><br>
                          <input type="Radio" class="btn btn-group" name="gender" value="Laki-Laki"> Laki-laki &nbsp&nbsp&nbsp&nbsp
                          <input type="Radio" class="btn btn-group" name="gender" value="Perempuan"> Perempuan
                      </div>

                      <div class="form-group">
                          <Label>Alamat :</Label>
                          <textarea name="alamat" class="form-control" placeholder="Enter Your Address.."></textarea>
                    </div>

                     <div class="form-group">
                          <Label>Email :</Label>
                          <input type="text" class="form-control" name="email" placeholder="Enter Your Email..">
                      </div>

                      <div class="form-group">
                          <Label>No Handphone :</Label>
                          <input type="text" class="form-control" name="nohp" placeholder="Enter Your Number..">
                      </div>

                      <div class="form-group">
                          <Label>Pendidikan Terakhir :</Label><br>
                          <input type="Radio" class="btn btn-group" name="pendidikan_terakhir" value="S1"> S1 &nbsp&nbsp&nbsp&nbsp
                          <input type="Radio" class="btn btn-group" name="pendidikan_terakhir" value="S2"> S2 &nbsp&nbsp&nbsp&nbsp
                          <input type="Radio" class="btn btn-group" name="pendidikan_terakhir" value="S3"> S3
                      </div>

                      <div class="form-group">
                          <Label>Foto Dosen :</Label><br>
                          <input type="file" class="btn btn-primary" name="foto">
                      </div>

                      

          
          <center><input type="submit" name="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>


