<?php
    include "../koneksi.php";
  mysqli_query($con,"delete from t_dosen where id_dosen='$_GET[id_dsn]'");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_dosen';
        </script>";
  ?>