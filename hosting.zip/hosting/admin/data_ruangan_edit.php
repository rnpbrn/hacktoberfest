<?php
include"../koneksi.php";
$sqlr = mysqli_query($con,"select * from t_ruangan where id_ruangan=$_GET[id_ruangan]");
$rr = mysqli_fetch_array($sqlr);
?>

<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">UPDATE DATA RUANGAN</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Kode Ruangan :</Label>
                          <input type="hidden" class="form-control" name="id_ruangan" value="<?php echo"$rr[id_ruangan]"?>">
                          <input type="text" class="form-control" name="kd_ruangan" value="<?php echo"$rr[kd_ruangan]"?>">
                    </div>


                    <div class="form-group">
                          <Label>Nama Ruangan :</Label>
                          <input type="text" class="form-control" name="nm_ruangan" value="<?php echo"$rr[nm_ruangan]"?>">
                    </div>

                     <div class="form-group">
                          <Label>Kapasitas :</Label>
                          <input type="text" class="form-control" name="kapasitas" value="<?php echo"$rr[kapasitas]"?>">
                      </div>



                      

          
                      <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                  </form>
                  
                </div>
              </div>
            </div>

  <?php
      if($_SERVER['REQUEST_METHOD']=="POST"){
          include"../koneksi.php";
  mysqli_query($con,"update t_ruangan set kd_ruangan='$_POST[kd_ruangan]',nm_ruangan='$_POST[nm_ruangan]', kapasitas='$_POST[kapasitas]' 
              where id_ruangan=$_POST[id_ruangan]");
  
  echo "<script language='javascript'>
          document.location='index_admin.php?page=data_ruangan';
      </script>";
      }
  
  ?>