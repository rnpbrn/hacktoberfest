<?php
include"../koneksi.php";
$sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$_GET[id_kelas]");
$rk = mysqli_fetch_array($sqlk);
?>

<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">UPDATE DATA KELAS</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Kode Kelas :</Label>
                          <input type="hidden" class="form-control" name="id_kelas" value="<?php echo"$rk[id_kelas]"?>">
                          <input type="text" class="form-control" name="kd_kelas" value="<?php echo"$rk[kd_kelas]"?>">
                    </div>


                    <div class="form-group">
                          <Label>Nama Kelas :</Label>
                          <input type="text" class="form-control" name="nm_kelas" value="<?php echo"$rk[nm_kelas]"?>">
                    </div>

                    <div class="form-group">
                          <Label>Jurusan :</Label><br>
                          <select class="form-control" name="jurusan">
                            <option value="<?php echo"$rk[jurusan]"?>"> <?php echo"$rk[jurusan]" ?>  </option>
                            <option value="S1 - Teknik Informatika"> S1 - Teknik Informatika</option>
                            <option value="S1 - Sistem Informasi"> S1 - Sistem Informasi </option>
                            <option value="S1 - Desain Komunikasi Visual">S1 - Desain Komunikasi Visual </option>
                            <option value="D3 - Manajemen Informatika">D3 - Manajemen Informatika </option>
                            <option value="D3 - Komputerisasi Akuntansi">D3 - Komputerisasi Akuntansi </option>
                          </select>
                    </div>
                    
                    <div class="form-group">
                          <Label>Semester :</Label><br>
                          <select class="form-control" name="semester">
                            <option value="<?php echo"$rk[semester]"?>"> <?php echo"$rk[semester]" ?>  </option>
                            <option value="Semester 1"> Semester 1</option>
                            <option value="Semester 2"> Semester 2</option>
                            <option value="Semester 3"> Semester 3</option>
                            <option value="Semester 4"> Semester 4</option>
                            <option value="Semester 5"> Semester 5</option>
                            <option value="Semester 6"> Semester 6</option>
                            <option value="Semester 7"> Semester 7</option>
                            <option value="Semester 8"> Semester 8</option>
                          </select>
                    </div>


                      <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                  </form>
                  
                </div>
              </div>
            </div>

  <?php
      if($_SERVER['REQUEST_METHOD']=="POST"){
          include"../koneksi.php";
  mysqli_query($con,"update t_kelas set kd_kelas='$_POST[kd_kelas]',nm_kelas='$_POST[nm_kelas]', 
  jurusan='$_POST[jurusan]',where semester=$_POST[semester]");
  
  echo "<script language='javascript'>
          document.location='index_admin.php?page=data_kelas';
      </script>";
      }
  
  ?>