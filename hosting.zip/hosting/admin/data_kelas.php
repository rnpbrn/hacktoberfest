<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Kelas</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="index_admin.php?page=data_kelas_input"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Tambah Data Kelas</a><p></p>

                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Kode Kelas</th>
                      <th>Nama Kelas </th>
                      <th>Jurusan </th>
                      <th>Semester</th>
                      <th>Action</th>
                    </tr>

                    <tfoot>
                      <th>No.</th>
                      <th>Kode Kelas</th>
                      <th>Nama Kelas </th>
                      <th>Jurusan </th>
                      <th>Semester</th>
                      <th>Action</th>
                    </tfoot>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqlk = mysqli_query($con," select * from t_kelas ");
                  $no=1;
                  while($rk= mysqli_fetch_array($sqlk)){
                        echo"
                        <tr>
                        <td>$no</td>
                        <td>$rk[kd_kelas]</td>
                        <td>$rk[nm_kelas]</td>
                        <td>$rk[jurusan]</td>
                        <td>$rk[semester]</td>
                        <td><a href='index_admin.php?page=cek_mahasiswa_kelas&id_kelas=$rk[id_kelas]'  class='d-none d-sm-inline-block btn btn-sm btn-success shadow-sm'>
                        Cek </a>
                        <a href='index_admin.php?page=data_mahasiswa_kelas&id_kelas=$rk[id_kelas]'  class='d-none d-sm-inline-block btn btn-sm btn-success shadow-sm'>
                        Tambah Mahasiswa </a>
                        <a href='index_admin.php?page=data_kelas_edit&id_kelas=$rk[id_kelas]'  class='d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm'>
                        Info </a>
                        <a href='index_admin.php?page=data_kelas_delete&id_kelas=$rk[id_kelas]'  class='d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm'>
                        Delete </a></td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>