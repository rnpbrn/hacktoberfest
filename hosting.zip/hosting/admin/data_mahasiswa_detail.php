<?php
include"../koneksi.php";
$sqlm = mysqli_query($con,"select * from t_mahasiswa where id_mahasiswa=$_GET[id_mahasiswa]");
$rm = mysqli_fetch_array($sqlm);
?>

<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">DATA DETAIL MAHASISWA</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>NIM Mahasiswa :</Label>
                          <input type="text" class="form-control" name="nim_mahasiswa" value="<?php echo"$rm[nim_mahasiswa]"?>">
                    </div>


                    <div class="form-group">
                          <Label>Nama Mahasiswa :</Label>
                          <input type="text" class="form-control" name="nm_mahasiswa" value="<?php echo"$rm[nm_mahasiswa]"?>">
                    </div>

                    <div class="form-group">
                          <Label>Gender :</Label><br>
                          <select class="form-control" name="gender">
                            <option value="<?php echo"$rm[gender]"?>"> <?php echo"$rm[gender]" ?>  </option>
                            <option value="laki-laki"> Laki - Laki </option>
                            <option value="perempuan"> Perempuan </option>
                          </select>
                    </div>

                    <div class="form-group">
                          <Label>Alamat :</Label>
                          <textarea name="alamat" class="form-control"><?php echo"$rm[alamat]"?></textarea>
                    </div>

                    <div class="form-group">
                          <Label>Email :</Label>
                          <input type="text" class="form-control" name="email" value="<?php echo"$rm[email]"?>">
                    </div>

                      <div class="form-group">
                          <Label>No Handphone :</Label>
                          <input type="text" class="form-control" name="nohp" value="<?php echo"$rm[nohp]"?>">
                    </div>

                      

          
          <center><a href="index_admin.php?page=data_mahasiswa"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Kembali </a></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>