<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">DATA JADWAL</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Nama Kelas :</Label>
                          <select class="form-control" name="id_kelas">
                          <?php
                          include"../koneksi.php";
                          $sqlk = mysqli_query($con," select * from t_kelas ");
                          $no=1;
                          while($rk= mysqli_fetch_array($sqlk)){
                          echo"
                          
                            <option value='$rk[id_kelas]'> $rk[nm_kelas] / $rk[semester]</option>";
                        
                          }
                          ?>
                          </select>
                    </div>

                    <div class="form-group">
                          <Label>Nama Dosen :</Label>
                          <select class="form-control" name="id_dosen">
                          <?php
                          include"../koneksi.php";
                          $sqld = mysqli_query($con," select * from t_dosen ");
                          $no=1;
                          while($rd= mysqli_fetch_array($sqld)){
                          echo"
                          
                            <option value='$rd[id_dosen]'> $rd[nm_dosen]</option>";
                        
                          }
                          ?>
                          </select>
                    </div>

                    <div class="form-group">
                          <Label>Nama Matakuliah :</Label>
                          <select class="form-control" name="id_mk">
                          <?php
                          include"../koneksi.php";
                          $sqlmk = mysqli_query($con," select * from t_matakuliah ");
                          $no=1;
                          while($rmk= mysqli_fetch_array($sqlmk)){
                          echo"
                          
                            <option value='$rmk[id_mk]'> $rmk[nm_mk]</option>";
                        
                          }
                          ?>
                          </select>
                    </div>

                     <div class="form-group">
                          <Label>Nama Ruangan :</Label>
                          <select class="form-control" name="id_ruangan">
                          <?php
                          include"../koneksi.php";
                          $sqlr = mysqli_query($con," select * from t_ruangan ");
                          $no=1;
                          while($rr= mysqli_fetch_array($sqlr)){
                          echo"
                          
                            <option value='$rr[id_ruangan]'> $rr[nm_ruangan]</option>";
                        
                          }
                          ?>
                          </select>
                    </div>  

                    <div class="form-group">
                          <Label>Hari :</Label>
                          <select class="form-control" name="hari">
                            <option value="Senin"> Senin</option>
                            <option value="Selasa"> Selasa </option>
                            <option value="Rabu"> Rabu </option>
                            <option value="Kamis"> Kamis </option>
                            <option value="Jum'at"> Jum'at </option>
                            <option value="Sabtu"> Sabtu </option>
                          </select>
                    </div>

                    <div class="form-group">
                          <Label>Jam :</Label>
                          <select class="form-control" name="jam">
                            <option value="07:30 - 9:30"> 07:30 - 9:30</option>
                            <option value="09:30 - 11:30"> 09:30 - 11:30 </option>
                            <option value="12:30 - 14:30"> 12:30 - 14:30 </option>
                            <option value="14:30 - 16:30"> 14:30 - 16:30 </option>
                          </select>
                    </div>

          <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>


<?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        include"../koneksi.php";
mysqli_query($con,"insert into t_jadwal (
    id_kelas,id_dosen,id_mk,id_ruangan,hari,jam) values ('$_POST[id_kelas]','$_POST[id_dosen]',
    '$_POST[id_mk]','$_POST[id_ruangan]','$_POST[hari]','$_POST[jam]')");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_jadwal';
    </script>";
    }

?>