<?php
    include "../koneksi.php";
  mysqli_query($con,"delete from t_kelas where id_kelas='$_GET[id_kelas]'");
  mysqli_query($con,"delete from kelas_mahasiswa where id_kelas='$_GET[id_kelas]'");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_kelas';
        </script>";
  ?>