
<?php
    include "../koneksi.php";
    $lokasi_file = $_FILES['foto']['tmp_name'];
    $tipe_file  = $_FILES['foto']['type'];
    $nama_file  = $_FILES['foto']['name'];
    $direktori  = "../dosen/image/$nama_file";
    if (!empty($lokasi_file)){
        move_uploaded_file($lokasi_file, $direktori);
mysqli_query($con,"update t_dosen set nidn='$_POST[nidn]',nm_dosen='$_POST[nm_dosen]',gender='$_POST[gender]',
            alamat='$_POST[alamat]',email='$_POST[email]', nohp='$_POST[nohp]', pendidikan_terakhir='$_POST[pendidikan_terakhir]', foto='$nama_file' where id_dosen=$_POST[id_dosen]");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_dosen';
    </script>";
    }

?>