<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">DATA KELAS</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Kode Kelas :</Label>
                          <input type="text" class="form-control" name="kd_kelas" placeholder="Enter The Code..">
                    </div>


                    <div class="form-group">
                          <Label>Nama Kelas :</Label>
                          <input type="text" class="form-control" name="nm_kelas" placeholder="Enter The Name..">
                    </div>

                    <div class="form-group">
                          <Label>Jurusan :</Label><br>
                          <select class="form-control" name="jurusan">
                            <option value="S1 - Teknik Informatika"> S1 - Teknik Informatika</option>
                            <option value="S1 - Sistem Informasi"> S1 - Sistem Informasi </option>
                            <option value="S1 - Desain Komunikasi Visual"> Desain Komunikasi Visual </option>
                            <option value="D3 - Manajemen Informatika"> Manajemen Informatika </option>
                            <option value="D3 - Komputerisasi Akuntansi"> Komputerisasi Akuntansi </option>
                          </select>
                    </div>

                    <div class="form-group">
                          <Label>Semester :</Label><br>
                          <select class="form-control" name="semester">
                            <option value="Semester 1"> Semester 1</option>
                            <option value="Semester 2"> Semester 2</option>
                            <option value="Semester 3"> Semester 3</option>
                            <option value="Semester 4"> Semester 4</option>
                            <option value="Semester 5"> Semester 5</option>
                            <option value="Semester 6"> Semester 6</option>
                            <option value="Semester 7"> Semester 7</option>
                            <option value="Semester 8"> Semester 8</option>
                          </select>
                    </div>



                      

          
          <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>


<?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        include"../koneksi.php";
mysqli_query($con,"insert into t_kelas (
    kd_kelas,nm_kelas,jurusan,semester) values ('$_POST[kd_kelas]','$_POST[nm_kelas]',
    '$_POST[jurusan]','$_POST[semester]')");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_kelas';
    </script>";
    }

?>