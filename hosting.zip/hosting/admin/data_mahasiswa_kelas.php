<?php
include"../koneksi.php";
$sqlm = mysqli_query($con,"select * from t_kelas where id_kelas=$_GET[id_kelas]");
$rm = mysqli_fetch_array($sqlm);
?>

<form name="form1" method="POST">
<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Mahasiswa</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                
                <label>Nama Kelas : <?php echo"$rm[nm_kelas]";?></label><br>
                <input type="hidden" class="form-control" name="id_kelas" value="<?php echo"$rm[id_kelas]";?>">
                <label>Semester : <?php echo"$rm[semester]";?></label><br>
                <label>Jurusan : <?php echo"$rm[jurusan]";?></label><br>

                  <thead>
                    <tr>
                      <th>No</th>
                      <th>NIM</th>
                      <th>Nama Mahasiswa</th>
                      <th>Gender</th>
                      <th align='center'>v</th>
                    </tr>
                  </thead>
                  
                  <tbody>

                    <?php
                    include"../koneksi.php";
                    $sqlm = mysql_query("select * from t_mahasiswa where NOT
                    EXISTS (select * from kelas_mahasiswa where t_mahasiswa.id_mahasiswa=kelas_mahasiswa.id_mahasiswa)");
                    $no=1;
                    while($rm= mysql_fetch_array($sqlm)){
                        echo"
                            <tr>
                            <td>$no</td>
                            <td>$rm[nim_mahasiswa]</td>
                            <td>$rm[nm_mahasiswa]</td>
                            <td>$rm[gender]</td>
                            <td align='center'> <input type='checkbox' name='id_mahasiswa[]' value='$rm[id_mahasiswa]'> </td>
                            </tr>";
                      $no++;
                    }


                    ?>
                  </tbody>
                </table>
                <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
              </div>
            </div>
          </div>
</form>

<?php
      if($_SERVER['REQUEST_METHOD']== "POST"){
        include "../koneksi.php";
        $id_mahasiswa = $_POST['id_mahasiswa'];
        $jumlah = count($id_mahasiswa);
        for ($i=0; $i <$jumlah ; $i++) { 
          mysql_query("insert into kelas_mahasiswa (
          id_kelas,id_mahasiswa) values ('$_POST[id_kelas]','$id_mahasiswa[$i]')");
        }
        echo "<script language='JavaScript'>
                  document.location='index_admin.php?page=data_kelas';
                  </script>";
      }
      ?>