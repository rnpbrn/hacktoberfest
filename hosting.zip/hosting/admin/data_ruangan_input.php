<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">DATA RUANGAN</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Kode Ruangan :</Label>
                          <input type="text" class="form-control" name="kd_ruangan" placeholder="Enter The Code..">
                    </div>


                    <div class="form-group">
                          <Label>Nama Ruangan :</Label>
                          <input type="text" class="form-control" name="nm_ruangan" placeholder="Enter The Name..">
                    </div>

                    <div class="form-group">
                          <Label>Kapasitas Ruangan :</Label>
                          <input type="text" class="form-control" name="kapasitas" placeholder="Enter The Capacity..">
                    </div>




                      

          
          <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>


<?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        include"../koneksi.php";
mysqli_query($con,"insert into t_ruangan (
    kd_ruangan,nm_ruangan,kapasitas) values ('$_POST[kd_ruangan]','$_POST[nm_ruangan]',
    '$_POST[kapasitas]')");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_ruangan';
    </script>";
    }

?>