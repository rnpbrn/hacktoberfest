<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Dosen</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="index_admin.php?page=data_dosen_input"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Tambah Data Dosen </a><p></p>


                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Foto</th>
                      <th>NIDN</th>
                      <th>Nama</th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqld = mysqli_query($con," select * from t_dosen ");
                  $no=1;
                  while($rd= mysqli_fetch_array($sqld)){
                        echo"
                        <tr>
                        <td>$no</td>
                        <td align='center' > <img src='../dosen/image/$rd[foto]' width='60px' height='60px' alt='foto' > </td>
                        <td>$rd[nidn]</td>
                        <td>$rd[nm_dosen]</td>
                        <td><a href='index_admin.php?page=data_dosen_detail&id_dsn=$rd[id_dosen]'  class='d-none d-sm-inline-block btn btn-sm btn-success shadow-sm'>
                        Detail </a>
                        <a href='index_admin.php?page=data_dosen_edit&id_dsn=$rd[id_dosen]'  class='d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm'>
                        Info </a>
                        <a href='index_admin.php?page=data_dosen_delete&id_dsn=$rd[id_dosen]'  class='d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm'>
                        Delete </a>";

                        $sqlu = mysqli_query($con," select * from t_user where username = '$rd[nidn]'");
                        $ru= mysqli_fetch_array($sqlu);

                        if($ru['username']==$rd['nidn']){
                          echo"";
                        
                        }
                        
                        else{
                        
                          echo"
                          <a href='index_admin.php?page=data_dosen_add&id_dsn=$rd[id_dosen]'  class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
                          Add User </a>";
                        }
                        
                        echo"</td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>