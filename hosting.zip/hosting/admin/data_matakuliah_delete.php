<?php
    include "../koneksi.php";
  mysqli_query($con,"delete from t_matakuliah where id_mk='$_GET[id_mk]'");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_matakuliah';
        </script>";
  ?>