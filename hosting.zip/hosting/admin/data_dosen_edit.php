<?php
include"../koneksi.php";
$sqlm = mysqli_query($con,"select * from t_dosen where id_dosen=$_GET[id_dsn]");
$rm = mysqli_fetch_array($sqlm);
?>

<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">UPDATE DATA DOSEN</h6>
                </div>
                <div class="card-body">
				    <form method="POST" enctype="multipart/form-data" action="index_admin.php?page=data_dosen_edit_aksi">
          
                    <div class="form-group">
                          <Label>NIDN Dosen:</Label>
                          <input type="hidden" class="form-control" name="id_dosen" value="<?php echo"$rm[id_dosen]"?>">
                          <input type="text" class="form-control" name="nidn" value="<?php echo"$rm[nidn]"?>">
                    </div>


                    <div class="form-group">
                          <Label>Nama Dosen :</Label>
                          <input type="text" class="form-control" name="nm_dosen" value="<?php echo"$rm[nm_dosen]"?>">
                    </div>

                    <div class="form-group">
                          <Label>Gender :</Label><br>
                          <select class="form-control" name="gender">
                            <option value="<?php echo"$rm[gender]"?>"> <?php echo"$rm[gender]" ?>  </option>
                            <option value="laki-laki"> Laki - Laki </option>
                            <option value="perempuan"> Perempuan </option>
                          </select>
                    </div>

                    <div class="form-group">
                          <Label>Alamat :</Label>
                          <textarea name="alamat" class="form-control"><?php echo"$rm[alamat]"?></textarea>
                    </div>

                    <div class="form-group">
                          <Label>Email :</Label>
                          <input type="text" class="form-control" name="email" value="<?php echo"$rm[email]"?>">
                    </div>

                      <div class="form-group">
                          <Label>No Handphone :</Label>
                          <input type="text" class="form-control" name="nohp" value="<?php echo"$rm[nohp]"?>">
                    </div>

                    <div class="form-group">
                          <Label>Pendidikan Terakhir :</Label><br>
                          <select class="form-control" name="pendidikan_terakhir">
                            <option value="<?php echo"$rm[pendidikan_terakhir]"?>"> <?php echo"$rm[pendidikan_terakhir]" ?>  </option>
                            <option value="S1"> S1 </option>
                            <option value="S2"> S2 </option>
                            <option value="S3"> S3 </option>
                          </select>
                    </div>
                      
                    <div class="form-group">
                          <Label>Foto Dosen :</Label><br>
                          <input type="file" class="btn btn-primary" name="foto">
                    </div>

          
                    <center><input type="submit" name="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                    </form>
                    
                  </div>
                </div>
              </div>
  
  
