<?php
    include "../koneksi.php";
  mysqli_query($con,"delete from t_ruangan where id_ruangan='$_GET[id_ruangan]'");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_ruangan';
        </script>";
  ?>