
<?php
    include "../koneksi.php";
    $lokasi_file = $_FILES['foto']['tmp_name'];
    $tipe_file  = $_FILES['foto']['type'];
    $nama_file  = $_FILES['foto']['name'];
    $direktori  = "../mahasiswa/image/$nama_file";
    if (!empty($lokasi_file)){
        move_uploaded_file($lokasi_file, $direktori);
mysqli_query($con,"update t_mahasiswa set nim_mahasiswa='$_POST[nim_mahasiswa]',nm_mahasiswa='$_POST[nm_mahasiswa]',gender='$_POST[gender]',
            alamat='$_POST[alamat]',email='$_POST[email]', nohp='$_POST[nohp]', foto='$nama_file' where id_mahasiswa=$_POST[id_mahasiswa]");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_mahasiswa';
    </script>";
    }

?>