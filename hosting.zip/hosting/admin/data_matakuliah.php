<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Mata Kuliah</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="index_admin.php?page=data_matakuliah_input"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Tambah Data Mata Kuliah </a><p></p>

                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Kode Mata Kuliah</th>
                      <th>Nama Mata Kuliah </th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqlm = mysqli_query($con," select * from t_matakuliah ");
                  $no=1;
                  while($rm= mysqli_fetch_array($sqlm)){
                        echo"
                        <tr>
                        <td>$no</td>
                        <td>$rm[kd_mk]</td>
                        <td>$rm[nm_mk]</td>
                        <td><a href='index_admin.php?page=data_matakuliah_detail&id_mk=$rm[id_mk]'  class='d-none d-sm-inline-block btn btn-sm btn-success shadow-sm'>
                        Detail </a>
                        <a href='index_admin.php?page=data_matakuliah_edit&id_mk=$rm[id_mk]'  class='d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm'>
                        Info </a>
                        <a href='index_admin.php?page=data_matakuliah_delete&id_mk=$rm[id_mk]'  class='d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm'>
                        Delete </a></td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>