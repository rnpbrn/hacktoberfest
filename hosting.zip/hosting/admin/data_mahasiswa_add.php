<?php
include"../koneksi.php";
$sqlm = mysqli_query($con,"select * from t_mahasiswa where id_mahasiswa=$_GET[id_mahasiswa]");
$rm = mysqli_fetch_array($sqlm);
?>

<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">EDIT DATA MAHASISWA</h6>
                </div>
                <div class="card-body">
			<form method="POST">
          

                   <div class="form-group">
                          <Label>Nama User :</Label>
                          <input type="text" class="form-control" name="nm_user" value="<?php echo"$rm[nm_mahasiswa]"?>">
                    </div>

                    <div class="form-group">
                          <Label>Username :</Label>
                          <input type="text" class="form-control" name="username" value="<?php echo"$rm[nim_mahasiswa]"?>">
                    </div>

                    <div class="form-group">
                          <Label>Password :</Label>
                          <input type="password" class="form-control" name="password" value="<?php echo"$rm[nim_mahasiswa]"?>">
                    </div>



          <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>


<?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        include"../koneksi.php";
        mysqli_query($con,"insert into t_user (
            nm_user,username,password,status) values ('$_POST[nm_user]','$_POST[username]',
            '$_POST[password]','Mahasiswa')");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_mahasiswa';
    </script>";
    }

?>