<?php
  
include "../koneksi.php";
$lokasi_file = $_FILES['foto']['tmp_name'];
$tipe_file  = $_FILES['foto']['type'];
$nama_file  = $_FILES['foto']['name'];
$direktori  = "../dosen/image/$nama_file";

if (!empty($lokasi_file)){
 move_uploaded_file($lokasi_file, $direktori);
 mysqli_query($con,"insert into t_dosen (nidn,nm_dosen,gender,alamat,email,nohp,pendidikan_terakhir,foto) values('$_POST[nidn]','$_POST[nm_dosen]','$_POST[gender]','$_POST[alamat]','$_POST[email]','$_POST[nohp]','$_POST[pendidikan_terakhir]','$nama_file')");
echo "<script language='JavaScript'>
        document.location='index_admin.php?page=data_dosen';
        </script>";
}  
?>