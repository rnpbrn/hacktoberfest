<?php
include"../koneksi.php";
$sqlm = mysqli_query($con,"select * from t_matakuliah where id_mk=$_GET[id_mk]");
$rm = mysqli_fetch_array($sqlm);
?>


<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary" align="center">DATA DETAIL MATA KULIAH</h6>
                </div>
                <div class="card-body">
				    <form method="POST">
          
                    <div class="form-group">
                          <Label>Kode Mata Kuliah :</Label>
                          <input type="text" class="form-control" name="kd_mk" value="<?php echo"$rm[kd_mk]"?>">
                    </div>


                    <div class="form-group">
                          <Label>Nama Mata Kuliah :</Label>
                          <input type="text" class="form-control" name="nm_mk" value="<?php echo"$rm[nm_mk]"?>">
                    </div>

                     <div class="form-group">
                          <Label>SKS :</Label>
                          <input type="text" class="form-control" name="sks" value="<?php echo"$rm[sks]"?>">
                      </div>



                      

          
                      <center><a href="index_admin.php?page=data_mahasiswa"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                Kembali </a></center>
                    
                    
                  </form>
                  
                </div>
              </div>
            </div>

            <?php
    if($_SERVER['REQUEST_METHOaD']=="POST"){
        include"../koneksi.php";
mysqli_query($con,"update t_mahasiswa set nim_mahasiswa='$_POST[nim_mahasiswa]',nm_mahasiswa='$_POST[nm_mahasiswa]',gender='$_POST[gender]',
            alamat='$_POST[alamat]',email='$_POST[email]', nohp='$_POST[nohp]' where id_mahasiswa=$_POST[id_mahasiswa]");

echo "<script language='javascript'>
        document.location='index_admin.php?page=data_mahasiswa';
    </script>";
    }

?>
