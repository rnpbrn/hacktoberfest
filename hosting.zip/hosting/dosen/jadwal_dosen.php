<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Jadwal</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">


                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Nama Kelas</th>
                      <th>Matakuliah </th>
                      <th>Ruangan</th>
                      <th>Waktu</th>
                      <th align='center'>Action</th>
                    </tr>

                    <tfoot>
                      <th>No.</th>
                      <th>Nama Kelas</th>
                      <th>Matakuliah </th>
                      <th>Ruangan</th>
                      <th>Waktu</th>
                      <th align='center'>Action</th>
                    </tfoot>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqld = mysqli_query($con,"select * from t_dosen where nidn=$ra[username]");
                  $rd= mysqli_fetch_array($sqld);
                  $sqlj = mysqli_query($con," select * from t_jadwal where id_dosen = '$rd[id_dosen]' ");
                  $no=1;
                  while($rj= mysqli_fetch_array($sqlj)){
                    $sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$rj[id_kelas]");
                    $rk= mysqli_fetch_array($sqlk);
                    $sqlmk = mysqli_query($con,"select * from t_matakuliah where id_mk=$rj[id_mk]");
                    $rmk= mysqli_fetch_array($sqlmk);
                    $sqlr = mysqli_query($con,"select * from t_ruangan where id_ruangan=$rj[id_ruangan]");
                    $rr= mysqli_fetch_array($sqlr);
                        echo"
                        <tr>
                        <td>$no</td>
                        <td>$rk[nm_kelas]</td>
                        <td>$rmk[nm_mk]</td>
                        <td>$rr[nm_ruangan]</td>
                        <td>$rj[hari] / $rj[jam]</td>
                        <td align='center'><a href='index_dosen.php?page=jadwal_mahasiswa&id_kelas=$rj[id_kelas]&id_mk=$rmk[id_mk]'  class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
                        Lihat Mahasiswa </a>
                        
                        </td>

                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>