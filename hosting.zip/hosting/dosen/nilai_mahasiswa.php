<?php
        include"../koneksi.php";
        $sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$_GET[id_kelas]");
        $rk = mysql_fetch_array($sqlk);

        $sqlj = mysqli_query($con,"select * from t_jadwal where id_jadwal=$_GET[id_jadwal]");
        $rj = mysql_fetch_array($sqlj);

        $sqlmk = mysqli_query($con,"select * from t_matakuliah where id_mk=$rj[id_mk]");
        $rmk = mysql_fetch_array($sqlmk);

        $sqlm = mysqli_query($con,"select * from t_mahasiswa where id_mahasiswa=$_GET[id_mahasiswa]");
        $rm = mysql_fetch_array($sqlm);
?>

<div class="col-lg-12 mb-4">
              <!-- Illustrations -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h1 class="m-0 font-weight-bold text-dark" align="center">Form Nilai Mahasiswa</h1>
            </div>
                <div class="card-body">
    
                    <form method="POST" class="user">

                    <input type="hidden" class="form-control" name="id_kelas" value="<?php echo"$rk[id_kelas]"; ?>">

                    <input type="hidden" class="form-control" name="id_jadwal" value="<?php echo"$rj[id_jadwal]"; ?>">

                    <input type="hidden" class="form-control" name="id_mahasiswa" value="<?php echo"$rm[id_mahasiswa]"; ?>">
          


                    <div class="form-group">
                          <Label>Nama Mahasiswa :</Label>
                          <input type="text" class="form-control" value="<?php echo"$rm[nm_mahasiswa]"; ?>" readonly="readonly">
                    </div>

                    <div class="form-group">
                          <Label>Nama Kuliah :</Label>
                          <input type="text" class="form-control" value="<?php echo"$rmk[nm_mk]"; ?>" readonly="readonly">
                    </div>

                    <div class="form-group">
                          <Label>Nilai UAS :</Label>
                          <input type="text" name="n_uas" class="form-control">
                    </div>

                    <div class="form-group">
                          <Label>Nilai UTS :</Label>
                          <input type="text" name="n_uts" class="form-control">
                    </div>

                    <div class="form-group">
                          <Label>Nilai Quiz :</Label>
                          <input type="text" name="n_quis" class="form-control">
                    </div>

                    <div class="form-group">
                          <Label>Nilai Sikap :</Label>
                          <input type="text" name="n_sikap" class="form-control">
                    </div>
                 
                    <center><input type="submit" class="btn btn-primary" value="Simpan Data" /></center>
                    
                    
                    </form>
                    
                  </div>
                </div>
              </div>
  
  
  <?php
      if($_SERVER['REQUEST_METHOD']=="POST"){
          include"../koneksi.php";
          $total = ($_POST['n_uas'] + $_POST['n_uts'] + $_POST['n_quis'] + $_POST['n_sikap'])/4;
          $n_total = $total / 25 ;
      
          if ($n_total >= 3.5) {
               $grade= "A";}
          elseif ($n_total >= "3") {
               $grade= "B";} 
          elseif ($n_total >= "2.78") {
               $grade= "C";} 
         elseif ($n_total >= "2") {
               $grade= "D";} 
          else {
               $grade= "E";} 
      
  mysqli_query($con,"insert into t_nilai (
      id_jadwal,id_kelas,id_mahasiswa,n_uas,n_uts,n_quis,n_sikap,n_total,grade) values ('$_POST[id_jadwal]','$_POST[id_kelas]',
      '$_POST[id_mahasiswa]','$_POST[n_uas]','$_POST[n_uts]','$_POST[n_quis]','$_POST[n_sikap]','$n_total','$grade')");
  
  echo "<script language='javascript'>
          document.location='index_dosen.php?page=jadwal_mahasiswa&id_kelas=$rj[id_kelas]&id_mk=$rmk[id_mk]';
      </script>";
      }
  
  ?>