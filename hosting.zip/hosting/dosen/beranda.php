<div class="row">
            <div class="col-lg-12 mb-4">
              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">SISTEM INFORMASI AKADEMIK UNIVERSITAS CATUR INSAN CENDEKIA</h6>
                </div>
                <div class="card-body">
                  <div class="text-center">
                    <img class="img-fluid px-0 px-sm-0 mt-1 mb-1" style="" src="../img/unic.png" alt="">
                  </div>
                  <p>
                  <p align=justify>
                  Selamat Datang Di Sistem Informasi Dosen Kampus <b>Universitas Catur Insan Cendekia</b>. Universitas CIC merupakan Kampus Yang Beralamat di Jl. Kesambi No.202, Kesambi, Kota Cirebon.
                  Kehadiran website Universitas CIC yang mudah diakses, akurat dan informatif, Terutama untuk para civitas AKamdemik CICPenelitian dan informasi lainnya.
                  Perkembangan komputer dan teknologi informasi yang begitu pesat dalam masa 20 tahun terakhir perlu diimbangi dengan ketersediaan sumber daya manusia yang profesional didaerah. Menjawab tantangan kebutuhan tersebut Universitas CIC turut berpartisipasi dengan menyelenggarakan program studi Sistem Informasi sejak setahun yang lalu. Menyongsong datangnya milenium baru dan era pasar bebas, tantangan dan persaingan kerja dalam bidang teknologi informasi akan semakin ketat. Tenaga kerja yang profesional dengan daya saing tinggi menjadi keharusan.
                  </p>

                  <p>
                  Dalam Website Sistem Informasi  ini dosen dapat mengetahui Profil Data Dosen, Daftar Mata Kuliah,Jadwal Perkuliahan Serta Kelola Data Nilai Mahasiswa..
                  </p>
                  <a target="_blank" rel="nofollow" href="#">For more information ? &rarr;</a>
                </div>
              </div>
            </div>
          </div>