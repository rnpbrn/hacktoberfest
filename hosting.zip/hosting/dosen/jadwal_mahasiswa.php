<?php
include"../koneksi.php";
$sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$_GET[id_kelas]");
$rk = mysqli_fetch_array($sqlk);
?>

<form name="form1" method="POST">
<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-dark">Data Mahasiswa</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                
                <label>Nama Kelas : <?php echo"$rk[nm_kelas]";?></label><br>
                <input type="hidden" class="form-control" name="id_kelas" value="<?php echo"$rk[id_kelas]";?>">
                <label>Semester : <?php echo"$rk[semester]";?></label><br>
                <label>Jurusan : <?php echo"$rk[jurusan]";?></label><br>

                  <thead>
                    <tr>
                      <th>No</th>
                      <th>NIM</th>
                      <th>Nama</th>
                      <th>Gender</th>
                      <th>Nilai UAS</th>
                      <th>Nilai UTS</th>
                      <th>Nilai Quiz</th>
                      <th>Nilai Sikap</th>
                      <th>IPK</th>
                      <th>Grade</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                  <tr>
                      <th>No</th>
                      <th>NIM</th>
                      <th>Nama</th>
                      <th>Gender</th>
                      <th>Nilai UAS</th>
                      <th>Nilai UTS</th>
                      <th>Nilai Quiz</th>
                      <th>Nilai Sikap</th>
                      <th>IPK</th>
                      <th>Grade</th>
                      <th>Action</th>
                    </tr>
                    </tfoot>
                  <tbody>

                    <?php
                    include"../koneksi.php";
                    $sqlkm = mysqli_query("select * from kelas_mahasiswa where id_kelas='$rk[id_kelas]'");
                    $no=1;
                    while($rkm= mysqli_fetch_array($sqlkm)){
                        $sqlm = mysqli_query($con,"select * from t_mahasiswa where id_mahasiswa=$rkm[id_mahasiswa]");
                        $rm = mysqli_fetch_array($sqlm);

                        $sqlmk = mysqli_query($con,"select * from t_matakuliah where id_mk=$_GET[id_mk]");
                        $rmk= mysqli_fetch_array($sqlmk);

                        $sqlj = mysqli_query ($con,"select * from t_jadwal where id_kelas='$rk[id_kelas]
                        'AND id_mk = $rmk[id_mk] ");
                        $rj = mysqli_fetch_array($sqlj);

                        $sqln = mysqli_query ($con,"select * from t_nilai where id_kelas='$rk[id_kelas]
                        'AND id_jadwal = '$rj[id_jadwal]' AND id_mahasiswa='$rm[id_mahasiswa]'");
                        $rn = mysql_fetch_array($sqln);
                        
                        echo"
                            <tr>
                            <td>$no</td>
                            <td>$rm[nim_mahasiswa]</td>
                            <td>$rm[nm_mahasiswa]</td>
                            <td>$rm[gender]</td>
                            <td>$rn[n_uas]</td>
                            <td>$rn[n_uts]</td>
                            <td>$rn[n_quis]</td>
                            <td>$rn[n_sikap]</td>
                            <td>$rn[n_total]</td>
                            <td>$rn[grade]</td>
                            <td align='center'>
                            <a href='index_dosen.php?page=nilai_mahasiswa&id_mahasiswa=$rm[id_mahasiswa]&id_kelas=$rk[id_kelas]&id_jadwal=$rj[id_jadwal]'class='d-none d-sm-inline-block btn btn-sm btn-success shadow-sm'>
                            Nilai Mahasiswa</a></td>
                        </td>
                            </tr>";
                      $no++;
                    }


                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>


<?php
      if($_SERVER['REQUEST_METHOD']== "POST"){
        include "../koneksi.php";
        $id_mahasiswa = $_POST['id_mahasiswa'];
        $jumlah = count($id_mahasiswa);
        for ($i=0; $i <$jumlah ; $i++) { 
          mysqli_query($con,"insert into mahasiswa_kelas (
          id_kelas,id_mahasiswa) values ('$_POST[id_kelas]','$id_mahasiswa[$i]')");
        }
        echo "<script language='JavaScript'>
                  document.location='index_admin.php?page=data_kelas';
                  </script>";
      }
      ?>