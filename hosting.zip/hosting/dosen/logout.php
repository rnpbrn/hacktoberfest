<?php
session_start();

$_SESSION['namadosen'] = '';
unset($_SESSION['namadosen']);
session_unset();
session_destroy();
header("location:../index.php")

?>

