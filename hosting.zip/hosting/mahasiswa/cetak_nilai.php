
<style>
 #watermark{
   margin: auto;
   top: 20%;
   right: 20%;
   left: 20%;
   display: block;
   position: absolute;
   opacity: 0.2;
   filter: alpha(opacity=30);

 }
</style>


<?php
session_start();
if(!isset($_SESSION['namamhs'])){

  

}
include "../koneksi.php";

$sqlm = mysqli_query($con,"select * from t_mahasiswa where nim_mahasiswa=$_SESSION[namamhs]");
$rm= mysqli_fetch_array($sqlm);

$sqlkm = mysqli_query($con,"select * from kelas_mahasiswa where id_mahasiswa='$rm[id_mahasiswa]'");
$rkm= mysqli_fetch_array($sqlkm);

$sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$rkm[id_kelas]");
$rk= mysqli_fetch_array($sqlk);

?>



<body onload="javascript:window.print()"
style="margin:0 auto;width: 100%;">

<div style="margin-left: 20px;margin-right:20px;">

<div id="watermark">
  <img src="../img/ware.png" width="100%" height="80%">
</div>

<table width="100%" cellpadding="0"
cellspacing="0">

  <tr>
    <td rowspan="3" align="center"><img src="../img/logo1.png" width="150" height="145">
    </td>

    <td><div align="center"><font size="5">
    KEMENTRIAN CATUR INSAN CENDEKIA
    </font>
    </div>  
    </td>
  </tr>

  <tr>
    <td><div align="center"><font size="6"> 
    UNIVERSITAS CATUR INSAN CENDEKIA
    </div></td>
  </tr>

  

  <tr>
    <td><div align="center"> 
    Jl. Kesambi No. 202 Kec.Kesambi,Kota Cirebon, Prov. Jawa Barat, Telp. (000)000000
    </div></td>

  </tr>
</table>


<hr><br>
<label><font size="5"><center>NILAI MAHASISWA</center></font></label>

<table>
  <tr>
    <td>Nama Mahasiswa</td>
    <td>:</td>
    <td><?php echo "$rm[nm_mahasiswa]" ?></td>
  </tr>

  <tr>
    <td>Kelas Mahasiswa</td>
    <td>:</td>
    <td><?php echo "$rk[nm_kelas]" ?></td>
  </tr>

  <tr>
    <td>Semester</td>
    <td>:</td>
    <td><?php echo "$rk[semester]" ?></td>
  </tr>

  
      
    </td>
  </tr>
</table>
<br>
<table style="border: 1px solid #000;" width="100%" cellpadding="0" cellspacing="0">
  <tr>
    <th style="border-right: 1px solid #000;">
    No.
    </th>

    <th style="border-right: 1px solid #000;">
    Nama Dosen
    </th>

    <th style="border-right: 1px solid #000;">
    Matakuliah
    </th>

    <th style="border-right: 1px solid #000;">
    Nilai UAS
    </th>

    <th style="border-right: 1px solid #000;">
    Nilai UTS
    </th>

    <th style="border-right: 1px solid #000;">
    Nilai Quiz
    </th>

    <th style="border-right: 1px solid #000;">
    Nilai Sikap
    </th>

    <th style="border-right: 1px solid #000;">
    Grade
    </th>

  </tr>
  <?php
  $sqlj = mysqli_query($con," select * from t_jadwal where id_kelas='$rkm[id_kelas]'");
                  $no=1;
                  while($rj= mysqli_fetch_array($sqlj)){

    $sqld = mysqli_query($con,"select * from t_dosen where id_dosen=$rj[id_dosen]");
                    $rd= mysqli_fetch_array($sqld);

    $sqlmk = mysqli_query($con,"select * from t_matakuliah where id_mk=$rj[id_mk]");
                        $rmk= mysqli_fetch_array($sqlmk);

    $sqln = mysqli_query ($con,"select * from t_nilai where id_kelas='$rj[id_kelas]
                        'AND id_jadwal = '$rj[id_jadwal]' AND id_mahasiswa='$rm[id_mahasiswa]'");
                        $rn = mysqli_fetch_array($sqln);

    echo "
      <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$no.</td>

       <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$rd[nm_dosen]</td>

       <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$rmk[nm_mk]</td>

       <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$rn[n_uas]</td>

       <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$rn[n_uts]</td>

       <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$rn[n_quis]</td>

       <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$rn[n_sikap]</td>

       <td align='center'
       style='border-right:1px solid #000; border-top:1px solid #000; padding:3px;'>$rn[grade]</td>
    </tr>";
    $no++;




    }
  ?>
  
</table>
<p style="text-align: right;font-size: 18px;solid #000;">Cirebon, <?php echo date("d M Y")?></p>
<br>

<p style="text-align: right;font-size: 18px;solid #000;">Rektor Universitas CIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>

<br>


<p style="text-align: right;font-size: 18px;solid #000;">Dr. Chandra Lukita, M.M&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>


</div>
</body>
