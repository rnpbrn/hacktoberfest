<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Jadwal Kuliah</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="cetak_jadwal.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-fw fa-print"></i>
                Cetak Jadwal</a><p></p>

                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Nama Kelas</th>
                      <th>Nama Dosen </th>
                      <th>Matakuliah </th>
                      <th>Ruangan</th>
                      <th>Waktu</th>
                    </tr>

                    <tfoot>
                      <th>No.</th>
                      <th>Nama Kelas</th>
                      <th>Nama Dosen </th>
                      <th>Matakuliah </th>
                      <th>Ruangan</th>
                      <th>Waktu</th>
                    </tfoot>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqlm = mysqli_query($con,"select * from t_mahasiswa where nim_mahasiswa=$ra[username]");
                    $rm= mysqli_fetch_array($sqlm);
                    $sqlkm = mysqli_query($con,"select * from kelas_mahasiswa where id_mahasiswa='$rm[id_mahasiswa]'");
                    $rkm= mysqli_fetch_array($sqlkm);
                  $sqlj = mysqli_query($con," select * from t_jadwal where id_kelas = '$rkm[id_kelas]' ");
                  $no=1;
                  while($rj= mysqli_fetch_array($sqlj)){
                    $sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$rj[id_kelas]");
                    $rk= mysqli_fetch_array($sqlk);
                    $sqld = mysqli_query($con,"select * from t_dosen where id_dosen=$rj[id_dosen]");
                    $rd= mysqli_fetch_array($sqld);
                    $sqlmk = mysqli_query($con,"select * from t_matakuliah where id_mk=$rj[id_mk]");
                    $rmk= mysqli_fetch_array($sqlmk);
                    $sqlr = mysqli_query($con,"select * from t_ruangan where id_ruangan=$rj[id_ruangan]");
                    $rr= mysql_fetch_array($sqlr);
                        echo"
                        <tr>
                        <td>$no</td>
                        <td>$rk[nm_kelas]</td>
                        <td>$rd[nm_dosen]</td>
                        <td>$rmk[nm_mk]</td>
                        <td>$rr[nm_ruangan]</td>
                        <td>$rj[hari] / $rj[jam]</td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>