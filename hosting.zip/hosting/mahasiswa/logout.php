<?php
session_start();

$_SESSION['namamhs'] = '';
unset($_SESSION['namamhs']);
session_unset();
session_destroy();
header("location:../index.php")

?>

