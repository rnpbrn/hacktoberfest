<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Nilai</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <a href="cetak_nilai.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-fw fa-print"></i>
                Cetak Nilai</a><p></p>

                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Kode MK </th>
                      <th>Mata Kuliah </th>
                      <th>Nama Dosen </th>
                      <th>Nilai UAS</th>
                      <th>Nilai UTS</th>
                      <th>Nilai Quiz</th>
                      <th>Nilai Sikap</th>
                      <th>Grade</th>
                    </tr>

                    <tfoot>
                      <th>No.</th>
                      <th>Kode MK </th>
                      <th>Mata Kuliah </th>
                      <th>Nama Dosen </th>
                      <th>Nilai UAS</th>
                      <th>Nilai UTS</th>
                      <th>Nilai Quiz</th>
                      <th>Nilai Sikap</th>
                      <th>Grade</th>
                    </tfoot>
                  </thead>

                  <tbody>
                  <?php

                  include"../koneksi.php";
                  $sqlm = mysqli_query($con,"select * from t_mahasiswa where nim_mahasiswa=$ra[username]");
                    $rm= mysqli_fetch_array($sqlm);

                    $sqlkm = mysqli_query($con,"select * from kelas_mahasiswa where id_mahasiswa='$rm[id_mahasiswa]'");
                    $rkm= mysqli_fetch_array($sqlkm);

                  $sqlj = mysqli_query($con," select * from t_jadwal where id_kelas = '$rkm[id_kelas]' ");
                  $no=1;
                  while($rj= mysqli_fetch_array($sqlj)){
                    $sqlk = mysqli_query($con,"select * from t_kelas where id_kelas=$rj[id_kelas]");
                    $rk= mysqli_fetch_array($sqlk);

                    $sqld = mysqli_query($con,"select * from t_dosen where id_dosen=$rj[id_dosen]");
                    $rd= mysqli_fetch_array($sqld);

                    $sqlmk = mysqli_query($con,"select * from t_matakuliah where id_mk=$rj[id_mk]");
                    $rmk= mysqli_fetch_array($sqlmk);

                    $sqlr = mysqli_query($con,"select * from t_ruangan where id_ruangan=$rj[id_ruangan]");
                    $rr= mysqli_fetch_array($sqlr);

                    $sqln = mysqli_query ($con,"select * from t_nilai where id_kelas='$rk[id_kelas]
                    'AND id_jadwal = '$rj[id_jadwal]' AND id_mahasiswa='$rm[id_mahasiswa]'");
                    $rn = mysqli_fetch_array($sqln);

                        echo"
                        <tr>
                        <td>$no</td>
                        <td>$rmk[kd_mk]</td>
                        <td>$rmk[nm_mk]</td>
                        <td>$rd[nm_dosen]</td>
                        <td>$rn[n_uas]</td>
                        <td>$rn[n_uts]</td>
                        <td>$rn[n_quis]</td>
                        <td>$rn[n_sikap]</td>
                        <td>$rn[grade]</td>
                        </tr>
                        ";
                  $no++;


                  }
                  

                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>